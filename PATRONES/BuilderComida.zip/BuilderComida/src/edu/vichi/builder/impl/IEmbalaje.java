/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.vichi.builder.impl;

/**
 *
 * @author jaevi
 */
public interface IEmbalaje {

public String empaquetar();    
}

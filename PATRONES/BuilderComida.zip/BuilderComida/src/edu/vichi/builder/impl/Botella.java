/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.vichi.builder.impl;

/**
 *
 * @author jaevi
 */
public class Botella implements IEmbalaje{

    @Override
    public String empaquetar() {
   return "Botella de plastico";
    }
    
}

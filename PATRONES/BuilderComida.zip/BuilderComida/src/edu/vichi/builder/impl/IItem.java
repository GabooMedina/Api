
package edu.vichi.builder.impl;

public interface IItem {
public String getNombre();
public IEmbalaje embalaje();
public float getPrecio();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.vichi.strategy.impl;

/**
 *
 * @author jaevi
 */
public class Principal {
    private String username;
    private String rol;

    public Principal(String username, String rol) {
        this.username = username;
        this.rol = rol;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.diego.decorator.inter;

/**
 *
 * @author Asus
 */
public interface ICuenta {
    //interface comun o componente
    public String getDescripcion();
    public double getCosto();  
}

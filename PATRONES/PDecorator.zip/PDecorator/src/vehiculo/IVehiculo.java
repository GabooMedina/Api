/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package vehiculo;

/**
 *
 * @author jaevi
 */
public interface IVehiculo {
    public void encender();
    public void acelerar();
    public void detenerse();
    
}
